# PyBACCHUS
A Python Wrapper for running the Brussels Automatic Code for Characterizing High accUracy Spectra (BACCHUS)
