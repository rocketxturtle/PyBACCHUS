__version__ = "1.0.0"

# set Python env variable to keep track of example data dir
DATADIR = os.path.dirname(__file__)

print("You have successfully imported PyBACCHUS! Good luck!!!\n")